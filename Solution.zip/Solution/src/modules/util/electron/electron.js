import { LightningElement } from 'lwc';

export default class Electron extends LightningElement {}
