#!/bin/bash

npm run build:development
cd ../ELECTRON
npm run start